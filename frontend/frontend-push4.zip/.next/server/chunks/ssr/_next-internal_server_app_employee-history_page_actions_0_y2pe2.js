module.exports=[35174,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_employee-history_page_actions_0_y2pe2.js.map