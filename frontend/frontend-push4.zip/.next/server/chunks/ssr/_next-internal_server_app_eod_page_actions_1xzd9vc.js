module.exports=[95650,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_eod_page_actions_1xzd9vc.js.map