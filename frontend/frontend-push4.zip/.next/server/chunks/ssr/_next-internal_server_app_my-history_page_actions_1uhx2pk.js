module.exports=[76982,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_my-history_page_actions_1uhx2pk.js.map