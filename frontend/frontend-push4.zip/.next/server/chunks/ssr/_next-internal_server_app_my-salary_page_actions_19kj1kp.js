module.exports=[26831,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_my-salary_page_actions_19kj1kp.js.map