module.exports=[26520,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_salaries_page_actions_19b-u-8.js.map