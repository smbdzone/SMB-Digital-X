module.exports=[13966,a=>{"use strict";var b=a.i(87924),c=a.i(38246),d=a.i(27348);a.s(["default",0,({children:a="Add Employee",href:e,onClick:f,type:g="button",disabled:h=!1,loading:i=!1,icon:j,className:k=""})=>{let l=h||i,m=(0,b.jsxs)(b.Fragment,{children:[i?(0,b.jsx)(d.FiLoader,{className:"size-4 animate-spin"}):j,(0,b.jsx)("span",{children:i?"Please wait...":a})]}),n=`
        group relative inline-flex h-12 items-center justify-center gap-2
        overflow-hidden rounded-xl
        bg-gradient-to-r from-blue-500 to-blue-600
        px-5 text-sm font-semibold text-white
        shadow-lg shadow-blue-500/25
        transition-all duration-300
        hover:scale-[1.02]
        hover:shadow-xl hover:shadow-blue-500/30
        active:scale-[0.98]
        focus:outline-none focus:ring-2
        focus:ring-blue-500/40 focus:ring-offset-2
        disabled:pointer-events-none disabled:cursor-not-allowed
        disabled:opacity-60 disabled:hover:scale-100
        ${k}
    `;return e?(0,b.jsxs)(c.default,{href:e,className:n,"aria-disabled":l,tabIndex:l?-1:void 0,onClick:a=>{l?a.preventDefault():f?.()},children:[(0,b.jsx)("span",{className:"absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-700 group-hover:translate-x-full"}),(0,b.jsx)("span",{className:"relative flex items-center gap-2",children:m})]}):(0,b.jsxs)("button",{type:g,disabled:l,onClick:f,className:n,children:[(0,b.jsx)("span",{className:"absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-700 group-hover:translate-x-full"}),(0,b.jsx)("span",{className:"relative flex items-center gap-2",children:m})]})}])},18180,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(27348);let e=(0,c.forwardRef)(({value:a,handleChange:e,label:f,error:g,helperText:h,leftIcon:i,rightIcon:j,containerClassName:k="",labelClassName:l="",showPasswordToggle:m=!1,type:n="text",className:o="",required:p,disabled:q,...r},s)=>{let[t,u]=(0,c.useState)(!1),v="password"===n,w=v&&t?"text":n;return(0,b.jsxs)("div",{className:`w-full ${k}`,children:[f&&(0,b.jsxs)("label",{className:`
                            mb-2 block text-sm font-medium
                            text-charcoal
                            ${l}
                        `,children:[f,p&&(0,b.jsx)("span",{className:"ml-1 text-red-500",children:"*"})]}),(0,b.jsxs)("div",{className:"relative",children:[i&&(0,b.jsx)("div",{className:"\r\n\n                                pointer-events-none\r\n\n                                absolute left-3 top-1/2\r\n\n                                -translate-y-1/2\r\n\n                                text-charcoal/40\r\n\n                            ",children:i}),(0,b.jsx)("input",{ref:s,...r,value:a,onChange:e,type:w,disabled:q,required:p,className:`
                            h-11 w-full
                            rounded-xl
                            border
                            bg-surface
                            px-3
                            text-sm text-charcoal
                            outline-none
                            transition-all duration-200

                            placeholder:text-charcoal/35

                            ${i?"pl-10":""}

                            ${j||v&&m?"pr-10":""}

                            ${g?`
                                        border-red-400
                                        focus:border-red-500
                                        focus:ring-4
                                        focus:ring-red-500/10
                                    `:`
                                        border-charcoal/10
                                        hover:border-charcoal/20
                                        focus:border-blue-500
                                        focus:ring-4
                                        focus:ring-blue-500/10
                                    `}

                            disabled:cursor-not-allowed
                            disabled:bg-charcoal/3
                            disabled:opacity-60

                            ${o}
                        `}),v&&m&&(0,b.jsx)("button",{type:"button",onClick:()=>u(a=>!a),disabled:q,tabIndex:-1,className:"\r\n\n                                absolute right-3 top-1/2\r\n\n                                -translate-y-1/2\r\n\n                                text-charcoal/40\r\n\n                                transition-colors\r\n\n                                hover:text-charcoal\r\n\n                                disabled:pointer-events-none\r\n\n                            ","aria-label":t?"Hide password":"Show password",children:t?(0,b.jsx)(d.FiEyeOff,{className:"size-4"}):(0,b.jsx)(d.FiEye,{className:"size-4"})}),!(v&&m)&&j&&(0,b.jsx)("div",{className:"\r\n\n                                    pointer-events-none\r\n\n                                    absolute right-3 top-1/2\r\n\n                                    -translate-y-1/2\r\n\n                                    text-charcoal/40\r\n\n                                ",children:j})]}),g&&(0,b.jsx)("p",{className:"mt-1.5 text-xs font-medium text-red-500",children:g}),!g&&h&&(0,b.jsx)("p",{className:"mt-1.5 text-xs text-charcoal/50",children:h})]})});e.displayName="Input",a.s(["default",0,e])},76487,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(27348);a.s(["default",0,({open:a,onClose:e,title:f,description:g,children:h,footer:i,size:j="md",closeOnOverlayClick:k=!0,closeOnEscape:l=!0,showCloseButton:m=!0,className:n=""})=>((0,c.useEffect)(()=>{if(!a||!l)return;let b=a=>{"Escape"===a.key&&e()};return document.addEventListener("keydown",b),()=>{document.removeEventListener("keydown",b)}},[a,l,e]),(0,c.useEffect)(()=>{if(!a)return;let b=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=b}},[a]),a)?(0,b.jsx)("div",{className:"\r\n\n                fixed inset-0 z-50\r\n\n                flex items-center justify-center\r\n\n                bg-charcoal/60\r\n\n                backdrop-blur-sm\r\n\n                p-4\r\n\n            ",onMouseDown:a=>{a.target===a.currentTarget&&k&&e()},role:"dialog","aria-modal":"true","aria-labelledby":f?"modal-title":void 0,children:(0,b.jsxs)("div",{className:`
                    relative w-full ${{sm:"max-w-sm",md:"max-w-md",lg:"max-w-lg",xl:"max-w-xl","2xl":"max-w-2xl","4xl":"max-w-4xl"}[j]}
                    max-h-[90vh]
                    overflow-hidden
                    rounded-2xl
                    border border-black/5
                    bg-white
                    shadow-2xl shadow-black/10
                    animate-in fade-in zoom-in-95
                    duration-200
                    ${n}
                `,onMouseDown:a=>a.stopPropagation(),children:[(f||g||m)&&(0,b.jsxs)("div",{className:"flex items-start justify-between gap-4 border-b border-black/5 px-6 py-5",children:[(0,b.jsxs)("div",{className:"min-w-0",children:[f&&(0,b.jsx)("h2",{id:"modal-title",className:"text-lg font-semibold text-charcoal",children:f}),g&&(0,b.jsx)("p",{className:"mt-1 text-sm leading-6 text-charcoal/60",children:g})]}),m&&(0,b.jsx)("button",{type:"button",onClick:e,"aria-label":"Close modal",className:"\r\n\n                                    flex size-9 shrink-0 items-center\r\n\n                                    justify-center rounded-lg\r\n\n                                    text-charcoal/50\r\n\n                                    transition-all\r\n\n                                    hover:bg-charcoal/5\r\n\n                                    hover:text-charcoal\r\n\n                                    active:scale-95\r\n\n                                ",children:(0,b.jsx)(d.FiX,{className:"size-5"})})]}),(0,b.jsx)("div",{className:"max-h-[calc(90vh-150px)] overflow-y-auto px-6 py-6",children:h}),i&&(0,b.jsx)("div",{className:"flex items-center justify-end gap-3 border-t border-black/5 bg-charcoal/[0.015] px-6 py-4",children:i})]})}):null])}];

//# sourceMappingURL=components_ui_0phz9mp._.js.map