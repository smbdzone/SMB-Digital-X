globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/nIxN47EcGXMYHrEUDooaq/_buildManifest.js",
    "static/nIxN47EcGXMYHrEUDooaq/_ssgManifest.js",
    "static/nIxN47EcGXMYHrEUDooaq/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/02fh7_m5mrih8.js",
    "static/chunks/0v4q862lvcmk5.js",
    "static/chunks/turbopack-0e2--302i54bc.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
