(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,74302,e=>{"use strict";var a=e.i(43476),r=e.i(22016),t=e.i(92199);e.s(["default",0,({children:e="Add Employee",href:n,onClick:s,type:l="button",disabled:o=!1,loading:i=!1,icon:d,className:c=""})=>{let u=o||i,x=(0,a.jsxs)(a.Fragment,{children:[i?(0,a.jsx)(t.FiLoader,{className:"size-4 animate-spin"}):d,(0,a.jsx)("span",{children:i?"Please wait...":e})]}),m=`
        group relative inline-flex h-12 items-center justify-center gap-2
        overflow-hidden rounded-xl
        bg-gradient-to-r from-blue-500 to-blue-600
        px-5 text-sm font-semibold text-white
        shadow-lg shadow-blue-500/25
        transition-all duration-300
        hover:scale-[1.02]
        hover:shadow-xl hover:shadow-blue-500/30
        active:scale-[0.98]
        focus:outline-none focus:ring-2
        focus:ring-blue-500/40 focus:ring-offset-2
        disabled:pointer-events-none disabled:cursor-not-allowed
        disabled:opacity-60 disabled:hover:scale-100
        ${c}
    `;return n?(0,a.jsxs)(r.default,{href:n,className:m,"aria-disabled":u,tabIndex:u?-1:void 0,onClick:e=>{u?e.preventDefault():s?.()},children:[(0,a.jsx)("span",{className:"absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-700 group-hover:translate-x-full"}),(0,a.jsx)("span",{className:"relative flex items-center gap-2",children:x})]}):(0,a.jsxs)("button",{type:l,disabled:u,onClick:s,className:m,children:[(0,a.jsx)("span",{className:"absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-700 group-hover:translate-x-full"}),(0,a.jsx)("span",{className:"relative flex items-center gap-2",children:x})]})}])},1206,e=>{"use strict";var a=e.i(43476),r=e.i(71645),t=e.i(92199);let n=(0,r.forwardRef)(({value:e,handleChange:n,label:s,error:l,helperText:o,leftIcon:i,rightIcon:d,containerClassName:c="",labelClassName:u="",showPasswordToggle:x=!1,type:m="text",className:h="",required:b,disabled:f,...p},v)=>{let[g,w]=(0,r.useState)(!1),j="password"===m,y=j&&g?"text":m;return(0,a.jsxs)("div",{className:`w-full ${c}`,children:[s&&(0,a.jsxs)("label",{className:`
                            mb-2 block text-sm font-medium
                            text-charcoal
                            ${u}
                        `,children:[s,b&&(0,a.jsx)("span",{className:"ml-1 text-red-500",children:"*"})]}),(0,a.jsxs)("div",{className:"relative",children:[i&&(0,a.jsx)("div",{className:"\r\n\n                                pointer-events-none\r\n\n                                absolute left-3 top-1/2\r\n\n                                -translate-y-1/2\r\n\n                                text-charcoal/40\r\n\n                            ",children:i}),(0,a.jsx)("input",{ref:v,...p,value:e,onChange:n,type:y,disabled:f,required:b,className:`
                            h-11 w-full
                            rounded-xl
                            border
                            bg-surface
                            px-3
                            text-sm text-charcoal
                            outline-none
                            transition-all duration-200

                            placeholder:text-charcoal/35

                            ${i?"pl-10":""}

                            ${d||j&&x?"pr-10":""}

                            ${l?`
                                        border-red-400
                                        focus:border-red-500
                                        focus:ring-4
                                        focus:ring-red-500/10
                                    `:`
                                        border-charcoal/10
                                        hover:border-charcoal/20
                                        focus:border-blue-500
                                        focus:ring-4
                                        focus:ring-blue-500/10
                                    `}

                            disabled:cursor-not-allowed
                            disabled:bg-charcoal/3
                            disabled:opacity-60

                            ${h}
                        `}),j&&x&&(0,a.jsx)("button",{type:"button",onClick:()=>w(e=>!e),disabled:f,tabIndex:-1,className:"\r\n\n                                absolute right-3 top-1/2\r\n\n                                -translate-y-1/2\r\n\n                                text-charcoal/40\r\n\n                                transition-colors\r\n\n                                hover:text-charcoal\r\n\n                                disabled:pointer-events-none\r\n\n                            ","aria-label":g?"Hide password":"Show password",children:g?(0,a.jsx)(t.FiEyeOff,{className:"size-4"}):(0,a.jsx)(t.FiEye,{className:"size-4"})}),!(j&&x)&&d&&(0,a.jsx)("div",{className:"\r\n\n                                    pointer-events-none\r\n\n                                    absolute right-3 top-1/2\r\n\n                                    -translate-y-1/2\r\n\n                                    text-charcoal/40\r\n\n                                ",children:d})]}),l&&(0,a.jsx)("p",{className:"mt-1.5 text-xs font-medium text-red-500",children:l}),!l&&o&&(0,a.jsx)("p",{className:"mt-1.5 text-xs text-charcoal/50",children:o})]})});n.displayName="Input",e.s(["default",0,n])},129,e=>{"use strict";var a=e.i(43476),r=e.i(71645),t=e.i(92199);e.s(["default",0,({open:e,onClose:n,title:s,description:l,children:o,footer:i,size:d="md",closeOnOverlayClick:c=!0,closeOnEscape:u=!0,showCloseButton:x=!0,className:m=""})=>((0,r.useEffect)(()=>{if(!e||!u)return;let a=e=>{"Escape"===e.key&&n()};return document.addEventListener("keydown",a),()=>{document.removeEventListener("keydown",a)}},[e,u,n]),(0,r.useEffect)(()=>{if(!e)return;let a=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=a}},[e]),e)?(0,a.jsx)("div",{className:"\r\n\n                fixed inset-0 z-50\r\n\n                flex items-center justify-center\r\n\n                bg-charcoal/60\r\n\n                backdrop-blur-sm\r\n\n                p-4\r\n\n            ",onMouseDown:e=>{e.target===e.currentTarget&&c&&n()},role:"dialog","aria-modal":"true","aria-labelledby":s?"modal-title":void 0,children:(0,a.jsxs)("div",{className:`
                    relative w-full ${{sm:"max-w-sm",md:"max-w-md",lg:"max-w-lg",xl:"max-w-xl","2xl":"max-w-2xl","4xl":"max-w-4xl"}[d]}
                    max-h-[90vh]
                    overflow-hidden
                    rounded-2xl
                    border border-black/5
                    bg-white
                    shadow-2xl shadow-black/10
                    animate-in fade-in zoom-in-95
                    duration-200
                    ${m}
                `,onMouseDown:e=>e.stopPropagation(),children:[(s||l||x)&&(0,a.jsxs)("div",{className:"flex items-start justify-between gap-4 border-b border-black/5 px-6 py-5",children:[(0,a.jsxs)("div",{className:"min-w-0",children:[s&&(0,a.jsx)("h2",{id:"modal-title",className:"text-lg font-semibold text-charcoal",children:s}),l&&(0,a.jsx)("p",{className:"mt-1 text-sm leading-6 text-charcoal/60",children:l})]}),x&&(0,a.jsx)("button",{type:"button",onClick:n,"aria-label":"Close modal",className:"\r\n\n                                    flex size-9 shrink-0 items-center\r\n\n                                    justify-center rounded-lg\r\n\n                                    text-charcoal/50\r\n\n                                    transition-all\r\n\n                                    hover:bg-charcoal/5\r\n\n                                    hover:text-charcoal\r\n\n                                    active:scale-95\r\n\n                                ",children:(0,a.jsx)(t.FiX,{className:"size-5"})})]}),(0,a.jsx)("div",{className:"max-h-[calc(90vh-150px)] overflow-y-auto px-6 py-6",children:o}),i&&(0,a.jsx)("div",{className:"flex items-center justify-end gap-3 border-t border-black/5 bg-charcoal/[0.015] px-6 py-4",children:i})]})}):null])}]);