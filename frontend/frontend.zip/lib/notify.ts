// Browser notifications shown while the website is open (any page).
// For a closed website see lib/push.ts (Web Push).

export const ensureNotificationPermission = async (): Promise<NotificationPermission | 'unsupported'> => {
    if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported'
    if (Notification.permission === 'default') return Notification.requestPermission()
    return Notification.permission
}

export const showChatNotification = (opts: { title: string; body: string; conversationId: string }) => {
    if (typeof window === 'undefined' || !('Notification' in window) || Notification.permission !== 'granted') return

    // same tag = a newer message of the same chat replaces the old notification (it also de-duplicates with Web Push)
    const notification = new Notification(opts.title, { body: opts.body, tag: `chat-${opts.conversationId}` })

    notification.onclick = () => {
        window.focus()
        window.location.assign(`/chat?conversationId=${opts.conversationId}`)
        notification.close()
    }
}
